
public abstract class Message 
{
	public abstract String toString();
	
}
